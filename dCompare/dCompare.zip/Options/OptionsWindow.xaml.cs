﻿using dCompare.Configuration;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;

namespace dCompare.Options
{
    public partial class OptionsWindow : Window
    {
        public OptionsWindow()
        {
            InitializeComponent();
            // Check if we are in design mode to avoid runtime errors in the designer
            if (!DesignerProperties.GetIsInDesignMode(this))
            {
                this.DataContext = new SettingsViewModel(new ConfigurationService());
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        // Placeholder text logic for the filter box
        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox tb = (TextBox)sender;
            if (tb.Text == (string)tb.Tag)
            {
                tb.Text = string.Empty;
                tb.Foreground = System.Windows.Media.Brushes.Black;
            }
        }

        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            TextBox tb = (TextBox)sender;
            if (string.IsNullOrWhiteSpace(tb.Text))
            {
                tb.Text = (string)tb.Tag;
                tb.Foreground = System.Windows.Media.Brushes.Gray;
            }
        }
    }

    //public class RelayCommand : ICommand
    //{
    //    private readonly Action<object> _execute;
    //    private readonly Predicate<object> _canExecute;
    //    public event EventHandler CanExecuteChanged
    //    {
    //        add { CommandManager.RequerySuggested += value; }
    //        remove { CommandManager.RequerySuggested -= value; }
    //    }
    //    public RelayCommand(Action<object> execute, Predicate<object> canExecute = null)
    //    {
    //        _execute = execute ?? throw new ArgumentNullException(nameof(execute));
    //        _canExecute = canExecute;
    //    }
    //    public bool CanExecute(object parameter) => _canExecute == null || _canExecute(parameter);
    //    public void Execute(object parameter) => _execute(parameter);
    //}
}