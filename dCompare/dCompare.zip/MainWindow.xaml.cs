﻿using dCompare.Compare;
using dCompare.Configuration;
using dCompare.Options;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Win32;
using Serilog;
using Serilog.Events;
using Serilog.Extensions.Logging;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.IO.Abstractions;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace dCompare
{
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        #region Properties and Fields

        public ICommand AddTabCommand { get; }
        public ICommand CloseTabCommand { get; }
        public ICommand SaveSessionCommand { get; }
        public ICommand LoadSessionCommand { get; }
        public ICommand ClearRecentSessionsCommand { get; }

        public ICommand OptionsCommand { get; }
        public ICommand CompareCommand { get; }
        public ICommand CopyToLeftCommand { get; }
        public ICommand CopyToRightCommand { get; }
        public ICommand ExpandAllCommand { get; }
        public ICommand CollapseAllCommand { get; }
        public ICommand ShowAllCommand { get; }
        public ICommand ShowDifferentCommand { get; }
        public ICommand ShowIdenticalCommand { get; }
        public ICommand ShowLeftUniqueCommand { get; }
        public ICommand ShowRightUniqueCommand { get; }

        private readonly ConfigurationService _configService;
        private readonly SessionManager _sessionManager;
        private readonly ILogger<ConfigurationService> _logger;
        private readonly IServiceProvider _serviceProvider;

        private TabItem _draggedTab;
        private Point _dragStartPoint;

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion

        #region Constructor

        public MainWindow()
        {
            InitializeComponent();

            // Set up dependency injection
            var services = new ServiceCollection();
            ConfigureServices(services);
            _serviceProvider = services.BuildServiceProvider();

            // Resolve dependencies
            _configService = _serviceProvider.GetRequiredService<ConfigurationService>();
            _sessionManager = _serviceProvider.GetRequiredService<SessionManager>();
            _logger = _serviceProvider.GetRequiredService<ILogger<ConfigurationService>>();

            // Initialize session manager
            _sessionManager.Initialize(tabControl, RecentSessionsMenu);

            // Initialize commands
            AddTabCommand = new RelayCommand(_ => AddNewTab(), _ => CanAddTab());
            CloseTabCommand = new RelayCommand(param => CloseTab(param as TabItem), param => CanCloseTab());
            SaveSessionCommand = new RelayCommand(_ => _sessionManager.SaveSession(UpdateStatus), _ => _sessionManager.CanSaveSession());
            LoadSessionCommand = new RelayCommand(_ => _sessionManager.LoadSession(null, false, UpdateStatus, ExecuteUcCompareMethod), _ => _sessionManager.CanLoadSession());
            ClearRecentSessionsCommand = new RelayCommand(_ => _sessionManager.ClearRecentSessions(), _ => _sessionManager.CanClearRecentSessions());

            OptionsCommand = new RelayCommand(_ => ExecuteOptions(), _ => CanExecuteOptions());
            CompareCommand = new RelayCommand(_ => ExecuteUcCompareMethod("Compare_Click"), _ => CanExecuteUcCompareMethod());
            CopyToLeftCommand = new RelayCommand(_ => ExecuteUcCompareMethod("CopyToLeft_Click"), _ => CanExecuteUcCompareMethod());
            CopyToRightCommand = new RelayCommand(_ => ExecuteUcCompareMethod("CopyToRight_Click"), _ => CanExecuteUcCompareMethod());
            ExpandAllCommand = new RelayCommand(_ => ExecuteUcCompareMethod("ExpandAll_Click"), _ => CanExecuteUcCompareMethod());
            CollapseAllCommand = new RelayCommand(_ => ExecuteUcCompareMethod("CollapseAll_Click"), _ => CanExecuteUcCompareMethod());
            ShowAllCommand = new RelayCommand(_ => ExecuteUcCompareMethod("ShowAll_Click"), _ => CanExecuteUcCompareMethod());
            ShowDifferentCommand = new RelayCommand(_ => ExecuteUcCompareMethod("ShowDifferent_Click"), _ => CanExecuteUcCompareMethod());
            ShowIdenticalCommand = new RelayCommand(_ => ExecuteUcCompareMethod("ShowIdentical_Click"), _ => CanExecuteUcCompareMethod());
            ShowLeftUniqueCommand = new RelayCommand(_ => ExecuteUcCompareMethod("ShowLeftUnique_Click"), _ => CanExecuteUcCompareMethod());
            ShowRightUniqueCommand = new RelayCommand(_ => ExecuteUcCompareMethod("ShowRightUnique_Click"), _ => CanExecuteUcCompareMethod());

            DataContext = this;

            Loaded += MainWindow_Loaded; // Subscribe to Loaded event
        }
        private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                AppConfiguration config = await _configService.LoadConfigurationAsync();
                if (config.Options?.Session.AutoLoadDefaultSession == true && !string.IsNullOrEmpty(config.Options.Session.DefaultSessionFile))
                {
                    _sessionManager.LoadSession(config.Options.Session.DefaultSessionFile, config.Options.Session.AutoCompareAfterSessionLoad, UpdateStatus, ExecuteUcCompareMethod);
                }
                else
                {
                    Log.Information("Application ready.");
                    UpdateStatus("Application ready");
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error loading configuration: {ex.Message}");
                // Handle error, e.g., show error message to user
            }
        }

        private void ConfigureServices(IServiceCollection services)
        {
            // Configure configuration
            var configuration = new ConfigurationBuilder()
                .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
                .AddJsonFile("dcompare.json", optional: true, reloadOnChange: true)
                .Build();
            services.AddSingleton<IConfiguration>(configuration);

            // Configure logging
            ConfigureLogging(configuration);
            services.AddSingleton<ILogger<ConfigurationService>>(provider =>
                new SerilogLoggerFactory(Log.Logger).CreateLogger<ConfigurationService>());

            // Configure file system
            services.AddSingleton<IFileSystem>(new FileSystem());

            // Configure services
            services.AddSingleton<ConfigurationService>();
            services.AddSingleton<SessionManager>();
        }

        private void ConfigureLogging(IConfiguration configuration)
        {
            var logConfig = configuration.GetSection("options:log").Get<LogOptions>() ?? new LogOptions();

            if (logConfig.Enabled)
            {
                var level = Enum.TryParse<LogEventLevel>(logConfig.Level, true, out var parsedLevel)
                    ? parsedLevel
                    : LogEventLevel.Information;

                Log.Logger = new LoggerConfiguration()
                    .MinimumLevel.Is(level)
                    .Enrich.WithThreadId()
                    .WriteTo.File(
                        path: "logs\\dCompare.log",
                        rollingInterval: RollingInterval.Day,
                        retainedFileCountLimit: logConfig.RetentionDays,
                        outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss:fff} [ThreadId:{ThreadId}] {Level:u3}: {Message}{NewLine}")
                    .CreateLogger();
            }
            else
            {
                Log.Logger = new LoggerConfiguration().CreateLogger();
            }
        }

        #endregion

        #region Tab Management

        private async void AddNewTab()
        {
            try
            {
                _sessionManager.TabCounter++;
                var tabId = Guid.NewGuid().ToString();
                var newTab = new TabItem
                {
                    Header = $"Tab {_sessionManager.TabCounter}",
                    Content = new UcCompare()
                };
                tabControl.Items.Add(newTab);
                tabControl.SelectedItem = newTab;
                _sessionManager.TabIdMap[newTab.Header.ToString()] = tabId;

                AppConfiguration config = await _configService.LoadConfigurationAsync();
                if (!config.Sessions.ContainsKey(tabId))
                {
                    await _configService.UpdateSessionAsync(tabId, string.Empty, string.Empty);
                }

                UpdateStatus($"Added new tab: Tab {_sessionManager.TabCounter}");
                CommandManager.InvalidateRequerySuggested();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding tab: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async void CloseTab(TabItem tab)
        {
            try
            {
                TabItem tabToClose = tab ?? tabControl.SelectedItem as TabItem;
                if (tabToClose == null || !tabControl.Items.Contains(tabToClose))
                {
                    UpdateStatus("No tab to close");
                    return;
                }

                bool showConfirmation = tabControl.Items.Count > 1 &&
                                       !tabToClose.Header.ToString().Equals("Welcome", StringComparison.OrdinalIgnoreCase);

                if (showConfirmation)
                {
                    MessageBoxResult result = MessageBox.Show(
                        $"Are you sure you want to close '{tabToClose.Header}'?",
                        "Confirm Close",
                        MessageBoxButton.YesNo,
                        MessageBoxImage.Question);

                    if (result != MessageBoxResult.Yes)
                    {
                        return;
                    }
                }

                int closedIndex = tabControl.Items.IndexOf(tabToClose);
                tabControl.Items.Remove(tabToClose);
                try
                {
                    var tabId = _sessionManager.TabIdMap[tabToClose.Header.ToString()];
                    _sessionManager.TabIdMap.Remove(tabToClose.Header.ToString());
                    await _configService.RemoveSessionAsync(tabId);
                }
                catch (Exception ex)
                {
                    Log.Warning("Failed to remove tab session: {Message}", ex.Message);
                    UpdateStatus($"Failed to remove tab session: {ex.Message}");
                }

                if (tabControl.Items.Count > 0)
                {
                    int newSelectedIndex = Math.Min(closedIndex, tabControl.Items.Count - 1);
                    tabControl.SelectedIndex = newSelectedIndex;
                }

                UpdateStatus($"Closed tab: {tabToClose.Header}");
                CommandManager.InvalidateRequerySuggested();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error closing tab: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                Log.Error("Error closing tab: {Message}", ex.Message);
            }
        }

        private bool CanAddTab()
        {
            return tabControl?.Items.Count < 20;
        }

        private bool CanCloseTab()
        {
            if (tabControl?.Items.Count == 0)
                return false;

            if (tabControl.Items.Count == 1)
            {
                var singleTab = tabControl.Items[0] as TabItem;
                return !singleTab?.Header.ToString().Equals("Welcome", StringComparison.OrdinalIgnoreCase) ?? false;
            }

            return true;
        }

        private void ExecuteOptions()
        {
            try
            {
                var optionsWindow = new OptionsWindow();
                optionsWindow.Owner = this;
                optionsWindow.ShowDialog();
                UpdateStatus("Options window opened");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error opening options: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private bool CanExecuteOptions()
        {
            return true;
        }

        private void ExecuteUcCompareMethod(string methodName)
        {
            try
            {
                if (tabControl.SelectedItem is TabItem selectedTab && selectedTab.Content is UcCompare ucCompare)
                {
                    MethodInfo methodInfo = typeof(UcCompare).GetMethod(methodName, BindingFlags.NonPublic | BindingFlags.Instance);
                    if (methodInfo != null)
                    {
                        methodInfo.Invoke(ucCompare, new object[] { null, null });
                        UpdateStatus($"{methodName.Replace("_Click", "")} executed");
                    }
                    else
                    {
                        MessageBox.Show($"{methodName} method not found", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
                else
                {
                    MessageBox.Show("No active tab to execute action", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error executing {methodName}: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private bool CanExecuteUcCompareMethod()
        {
            return tabControl?.SelectedItem is TabItem selectedTab && selectedTab.Content is UcCompare;
        }

        #endregion

        #region Drag and Drop

        private void TabItem_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (sender is TextBlock textBlock)
            {
                TabItem tabItem = FindAncestor<TabItem>(textBlock);
                if (tabItem != null)
                {
                    _draggedTab = tabItem;
                    _dragStartPoint = e.GetPosition(null);
                }   
            }
        }

        // Helper method to find the parent TabItem
        private static T FindAncestor<T>(DependencyObject current) where T : DependencyObject
        {
            while (current != null && !(current is T))
            {
                current = VisualTreeHelper.GetParent(current);
            }
            return current as T;
        }

        private void TabControl_PreviewMouseMove(object sender, MouseEventArgs e)
        {
            if (_draggedTab == null || e.LeftButton != MouseButtonState.Pressed)
                return;

            Point currentPoint = e.GetPosition(null);
            Vector diff = _dragStartPoint - currentPoint;

            if (Math.Abs(diff.X) > SystemParameters.MinimumHorizontalDragDistance ||
                Math.Abs(diff.Y) > SystemParameters.MinimumVerticalDragDistance)
            {
                try
                {
                    DragDrop.DoDragDrop(_draggedTab, _draggedTab, DragDropEffects.Move);
                }
                catch (Exception ex)
                {
                    UpdateStatus($"Drag operation failed: {ex.Message}");
                }
                finally
                {
                    _draggedTab = null;
                }
            }
        }

        private void TabItem_Drop(object sender, DragEventArgs e)
        {
            try
            {
                if (e.Data.GetData(typeof(TabItem)) is TabItem sourceTab &&
                    sender is TabItem targetTab &&
                    sourceTab != targetTab)
                {
                    int sourceIndex = tabControl.Items.IndexOf(sourceTab);
                    int targetIndex = tabControl.Items.IndexOf(targetTab);

                    if (sourceIndex >= 0 && targetIndex >= 0)
                    {
                        tabControl.Items.Remove(sourceTab);
                        tabControl.Items.Insert(targetIndex, sourceTab);
                        tabControl.SelectedItem = sourceTab;

                        UpdateStatus($"Moved tab '{sourceTab.Header}' to position {targetIndex + 1}");
                    }
                }
            }
            catch (Exception ex)
            {
                UpdateStatus($"Drop operation failed: {ex.Message}");
            }
            finally
            {
                _draggedTab = null;
            }
        }

        #endregion

        #region Menu Event Handlers

        private void RenameTab_Click(object sender, RoutedEventArgs e)
        {
            if (tabControl.SelectedItem is TabItem selectedTab)
            {
                string currentName = selectedTab.Header.ToString();
                string newName = PromptForTabName(currentName);

                if (!string.IsNullOrWhiteSpace(newName) && newName != currentName)
                {
                    string oldName = selectedTab.Header.ToString();
                    selectedTab.Header = newName;
                    if (_sessionManager.TabIdMap.ContainsKey(oldName))
                    {
                        string tabId = _sessionManager.TabIdMap[oldName];
                        _sessionManager.TabIdMap.Remove(oldName);
                        _sessionManager.TabIdMap[newName] = tabId;
                    }
                    UpdateStatus($"Renamed tab to: {newName}");
                }
            }
        }

        private void About_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(
                "dCompare - Chrome-style Tabbed Interface\n\n" +
                "Features:\n" +
                "• Chrome-style tabs with hover effects\n" +
                "• Drag and drop tab reordering\n" +
                "• Keyboard shortcuts (Ctrl+N, Ctrl+W)\n" +
                "• Tab close confirmation\n" +
                "• Unified color scheme\n" +
                "• Recent sessions history\n\n" +
                "Keyboard Shortcuts:\n" +
                "Ctrl+N: New Tab\n" +
                "Ctrl+W: Close Current Tab\n" +
                "Ctrl+S: Save Session\n" +
                "Ctrl+O: Load Session",
                "About dCompare",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            if (tabControl.Items.Count > 1)
            {
                MessageBoxResult result = MessageBox.Show(
                    "Are you sure you want to exit? All tabs will be closed.",
                    "Confirm Exit",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question);

                if (result != MessageBoxResult.Yes)
                    return;
            }

            Close();
        }

        #endregion

        #region Helper Methods

        private void UpdateStatus(string message)
        {
            if (StatusText != null)
            {
                StatusText.Text = message;
            }
        }

        private string PromptForTabName(string currentName)
        {
            return Microsoft.VisualBasic.Interaction.InputBox(
                "Enter new tab name:",
                "Rename Tab",
                currentName);
        }

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion

        #region Window Events

        protected override void OnClosing(CancelEventArgs e)
        {
            if (tabControl.Items.Count > 1)
            {
                MessageBoxResult result = MessageBox.Show(
                    "Are you sure you want to exit? All tabs will be closed.",
                    "Confirm Exit",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question);

                if (result != MessageBoxResult.Yes)
                {
                    e.Cancel = true;
                    return;
                }
            }

            base.OnClosing(e);
        }

        #endregion
    }

    public class RelayCommand : ICommand
    {
        private readonly Action<object> _execute;
        private readonly Func<object, bool> _canExecute;

        public RelayCommand(Action<object> execute, Func<object, bool> canExecute = null)
        {
            _execute = execute ?? throw new ArgumentNullException(nameof(execute));
            _canExecute = canExecute;
        }

        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }

        public bool CanExecute(object parameter)
        {
            try
            {
                return _canExecute?.Invoke(parameter) ?? true;
            }
            catch
            {
                return false;
            }
        }

        public void Execute(object parameter)
        {
            try
            {
                _execute(parameter);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Command execution failed: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}