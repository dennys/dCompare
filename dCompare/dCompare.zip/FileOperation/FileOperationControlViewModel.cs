using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using CommunityToolkit.Mvvm.Messaging;
using dCompare.Common;
using dCompare.FileOperation.Messages;
using dCompare.FileOperation.Models;
using dCompare.FileOperation.Strategies;
using Serilog;
using System.Collections.ObjectModel;
using System.IO;
using System.Windows.Data;

namespace dCompare.FileOperation
{
    public partial class FileOperationControlViewModel : ObservableObject,
        IRecipient<QueueTransferMessage>,
        IRecipient<CompleteTransferMessage>
    {
        private readonly FileManager _fileManager;
        private CancellationTokenSource _cancellationTokenSource;
        private bool _isPaused;

        [ObservableProperty]
        private ObservableCollection<FileTransfer> _queuedTransfers = new();

        [ObservableProperty]
        private ObservableCollection<FileTransfer> _successfulTransfers = new();

        [ObservableProperty]
        private ObservableCollection<FileTransfer> _failedTransfers = new();

        [ObservableProperty]
        private string? _filterText;

        public FileOperationControlViewModel()
        {
            _fileManager = new FileManager(new Kernel32FileCopyStrategy());
            _cancellationTokenSource = new CancellationTokenSource();

            // Register for messages
            WeakReferenceMessenger.Default.Register<QueueTransferMessage>(this);
            WeakReferenceMessenger.Default.Register<CompleteTransferMessage>(this);

            var queuedView = CollectionViewSource.GetDefaultView(QueuedTransfers);
            queuedView.Filter = FilterTransfers;
            var successfulView = CollectionViewSource.GetDefaultView(SuccessfulTransfers);
            successfulView.Filter = FilterTransfers;
            var failedView = CollectionViewSource.GetDefaultView(FailedTransfers);
            failedView.Filter = FilterTransfers;
        }

        [RelayCommand(CanExecute = nameof(CanStart))]
        private void OnStart()
        {
            _isPaused = false;
        }

        private bool CanStart() => _isPaused;

        [RelayCommand(CanExecute = nameof(CanPause))]
        private void OnPause()
        {
            _isPaused = true;
        }

        private bool CanPause() => !_isPaused;

        [RelayCommand(CanExecute = nameof(CanCancel))]
        private void OnCancel()
        {
            _cancellationTokenSource.Cancel();
            _cancellationTokenSource = new CancellationTokenSource();
        }

        private bool CanCancel() => QueuedTransfers.Any();

        [RelayCommand(CanExecute = nameof(CanCancelTransfer))]
        private void OnCancelTransfer(object parameter)
        {
            if (parameter is FileTransfer)
            {
                _cancellationTokenSource.Cancel();
                _cancellationTokenSource = new CancellationTokenSource();
            }
        }

        private bool CanCancelTransfer(object parameter) => parameter is FileTransfer;

        [RelayCommand(CanExecute = nameof(CanRetryTransfer))]
        private void OnRetryTransfer(object parameter)
        {
            if (parameter is FileTransfer transfer)
            {
                FailedTransfers.Remove(transfer);
                Transfer(transfer.Source, transfer.Target, true, transfer.Operation == FileOperationTypes.Copy, transfer.SourceType);
            }
        }

        private bool CanRetryTransfer(object parameter) => parameter is FileTransfer;

        [RelayCommand]
        private void OnFilterTextChanged()
        {
            CollectionViewSource.GetDefaultView(QueuedTransfers).Refresh();
            CollectionViewSource.GetDefaultView(SuccessfulTransfers).Refresh();
            CollectionViewSource.GetDefaultView(FailedTransfers).Refresh();
        }

        [RelayCommand(CanExecute = nameof(CanClearQueued))]
        private void OnClearQueued()
        {
            QueuedTransfers.Clear();
        }

        private bool CanClearQueued() => QueuedTransfers.Any();

        [RelayCommand(CanExecute = nameof(CanClearSuccessful))]
        private void OnClearSuccessful()
        {
            SuccessfulTransfers.Clear();
        }

        private bool CanClearSuccessful() => SuccessfulTransfers.Any();

        [RelayCommand(CanExecute = nameof(CanClearFailed))]
        private void OnClearFailed()
        {
            FailedTransfers.Clear();
        }

        private bool CanClearFailed() => FailedTransfers.Any();

        public void ClearQueuedTransfers()
        {
            App.Current.Dispatcher.Invoke(() => QueuedTransfers.Clear());
        }

        public void ClearSuccessfulTransfers()
        {
            App.Current.Dispatcher.Invoke(() => SuccessfulTransfers.Clear());
        }

        public void ClearFailedTransfers()
        {
            App.Current.Dispatcher.Invoke(() => FailedTransfers.Clear());
        }

        public void Receive(QueueTransferMessage message)
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                QueuedTransfers.Add(message.Transfer);
            });
        }

        public void Receive(CompleteTransferMessage message)
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                var transfer = message.Transfer;
                QueuedTransfers.Remove(transfer);
                transfer.Status = message.Success ? FileOperationStatus.Completed : FileOperationStatus.Failed;
                transfer.Progress = message.Success ? 1.0 : transfer.Progress;
                if (message.Success)
                {
                    SuccessfulTransfers.Add(transfer);
                }
                else
                {
                    FailedTransfers.Add(transfer);
                }
                LogTransfer(transfer);
            });
        }

        private static long GetItemSize(string path)
        {
            try
            {
                if (File.Exists(path))
                {
                    return new FileInfo(path).Length;
                }
                return 0; // Return 0 for directories
            }
            catch
            {
                return 0;
            }
        }

        public string Transfer(string source, string target, bool overwrite, bool isCopy, SourceType sourceType)
        {
            Log.Information($"Start to cp/mv {source} to {target}");
            string jobId = Guid.NewGuid().ToString();
            var transfer = new FileTransfer
            {
                JobId = jobId,
                Operation = isCopy ? FileOperationTypes.Copy : FileOperationTypes.Move,
                Source = source,
                Target = target,
                Status = FileOperationStatus.Queued,
                FileSize = GetItemSize(source),
                SourceType = sourceType
            };

            App.Current.Dispatcher.Invoke(() => QueuedTransfers.Add(transfer));

            Task.Run(async () =>
            {
                try
                {
                    var progress = new Progress<OperationProgress>(p =>
                    {
                        App.Current.Dispatcher.Invoke(() =>
                        {
                            transfer.Progress = p.Percentage / 100.0;
                            transfer.Status = FileOperationStatus.Transferring;
                            if (p.Percentage > 0)
                            {
                                transfer.TransferSpeed = (transfer.FileSize * (p.Percentage / 100.0) / 1024.0) / (DateTime.Now - transfer.StartTime).TotalSeconds;
                            }
                        });
                    });

                    while (_isPaused && !_cancellationTokenSource.Token.IsCancellationRequested)
                    {
                        await Task.Delay(100, _cancellationTokenSource.Token);
                    }

                    transfer.StartTime = DateTime.Now;

                    OperationResult result;
                    if (isCopy)
                    {
                        result = await _fileManager.CopyAsync(source, target, overwrite, progress, _cancellationTokenSource.Token);
                    }
                    else
                    {
                        result = await _fileManager.MoveAsync(source, target, overwrite, progress, _cancellationTokenSource.Token);
                    }

                    if (result.SuccessCount > 0)
                    {
                        App.Current.Dispatcher.Invoke(() =>
                        {
                            QueuedTransfers.Remove(transfer);
                            transfer.Status = FileOperationStatus.Completed;
                            transfer.Progress = 1.0;
                            SuccessfulTransfers.Add(transfer);
                            LogTransfer(transfer);
                        });

                    }
                    else
                    {
                        throw new Exception(string.Join("; ", result.FailedItems));
                    }
                }
                catch (OperationCanceledException)
                {
                    App.Current.Dispatcher.Invoke(() =>
                    {
                        QueuedTransfers.Remove(transfer);
                        transfer.Status = FileOperationStatus.Cancelled;
                        FailedTransfers.Add(transfer);
                        LogTransfer(transfer);
                    });
                }
                catch (Exception)
                {
                    App.Current.Dispatcher.Invoke(() =>
                    {
                        QueuedTransfers.Remove(transfer);
                        transfer.Status = FileOperationStatus.Failed;
                        FailedTransfers.Add(transfer);
                        LogTransfer(transfer);
                    });
                }
            }, _cancellationTokenSource.Token);
            return jobId;
        }

        private static void LogTransfer(FileTransfer transfer)
        {
            string logPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "FileOperationLog.txt");
            string logEntry = $"{DateTime.Now}: {transfer.Operation} - {transfer.Source} to {transfer.Target} - {transfer.Status.ToString()}\n";
            File.AppendAllText(logPath, logEntry);
        }

        private bool FilterTransfers(object item)
        {
            if (string.IsNullOrEmpty(FilterText))
                return true;

            var transfer = item as FileTransfer;
            string filter = FilterText.ToLowerInvariant();
            return transfer?.Source?.Contains(filter, StringComparison.OrdinalIgnoreCase) == true ||
                   transfer?.Target?.Contains(filter, StringComparison.OrdinalIgnoreCase) == true;
        }
    }
}
