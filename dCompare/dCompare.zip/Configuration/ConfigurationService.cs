﻿using dCompare.Common;
using Microsoft.Extensions.Configuration;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace dCompare.Configuration
{
    /// <summary>
    /// Service to manage loading, saving, and querying application configuration.
    /// </summary>
    public class ConfigurationService : IConfigurationService
    {
        private const string jsonFileName = Constant.DefaultConfigurationFile;
        private readonly string _configPath;
        private readonly IConfigurationRoot _configuration;
        private static readonly JsonSerializerOptions _serializerOptions = new()
        {
            WriteIndented = true,
            PropertyNameCaseInsensitive = true,
            Converters = { new JsonStringEnumConverter() }
        };

        /// <summary>
        /// Initializes a new instance of the ConfigurationService.
        /// </summary>
        /// <param name="configFileName">The name of the configuration file, e.g., "dCompare.json".</param>
        public ConfigurationService(string configFileName = jsonFileName)
        {
            _configPath = Path.Combine(Directory.GetCurrentDirectory(), configFileName);
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile(configFileName, optional: true, reloadOnChange: true);
            _configuration = builder.Build();
        }

        /// <summary>
        /// Loads the application configuration from the JSON file.
        /// If the file does not exist, it creates and saves a default configuration.
        /// </summary>
        /// <returns>An AppConfiguration object.</returns>
        public async Task<AppConfiguration> LoadConfigurationAsync()
        {
            if (!File.Exists(_configPath))
            {
                AppConfiguration defaultConfig = new();
                await SaveConfigurationAsync(defaultConfig);
                return defaultConfig;
            }
            try
            {
                var jsonString = await File.ReadAllTextAsync(_configPath);
                var config = JsonSerializer.Deserialize<AppConfiguration>(jsonString, _serializerOptions);
                if (config != null)
                {
                    ValidateConfiguration(config);
                }
                return config ?? new AppConfiguration();
            }
            catch (JsonException ex)
            {
                throw new InvalidDataException($"Error in configuration file at path: {ex.Path}. {ex.Message}", ex);
            }
            catch (Exception ex)
            {
                throw new InvalidDataException($"Error reading or deserializing configuration file: {ex.Message}", ex);
            }
        }

        private static void ValidateConfiguration(AppConfiguration config)
        {
            if (config.Options == null) return;

            var toolNames = new HashSet<string>(config.Options.Tools.Keys);

            foreach (var mapping in config.Options.FileTypeMapping.Values)
            {
                if (!string.IsNullOrEmpty(mapping.DefaultDiffTool) && !toolNames.Contains(mapping.DefaultDiffTool))
                {
                    throw new InvalidDataException($"The diff tool '{mapping.DefaultDiffTool}' set as the default for extensions '{string.Join(", ", mapping.Extensions)}' is not a defined tool.");
                }

                if (!string.IsNullOrEmpty(mapping.DefaultViewTool) && !toolNames.Contains(mapping.DefaultViewTool))
                {
                    throw new InvalidDataException($"The view tool '{mapping.DefaultViewTool}' set as the default for extensions '{string.Join(", ", mapping.Extensions)}' is not a defined tool.");
                }

                foreach (var toolName in mapping.PreferredTools.Diff)
                {
                    if (!toolNames.Contains(toolName))
                    {
                        throw new InvalidDataException($"The preferred diff tool '{toolName}' for extensions '{string.Join(", ", mapping.Extensions)}' is not a defined tool.");
                    }
                }

                foreach (var toolName in mapping.PreferredTools.View)
                {
                    if (!toolNames.Contains(toolName))
                    {
                        throw new InvalidDataException($"The preferred view tool '{toolName}' for extensions '{string.Join(", ", mapping.Extensions)}' is not a defined tool.");
                    }
                }
            }
        }

        /// <summary>
        /// Saves the provided configuration object to the JSON file.
        /// </summary>
        /// <param name="config">The AppConfiguration object to save.</param>
        public async Task SaveConfigurationAsync(AppConfiguration config)
        {
            var jsonString = JsonSerializer.Serialize(config, _serializerOptions);
            await File.WriteAllTextAsync(_configPath, jsonString);
            // Trigger reload to ensure configuration is updated
            _configuration.Reload();
        }

        /// <summary>
        /// Gets all enabled tools that support the given operation and extension.
        /// </summary>
        /// <param name="operation">The operation to check (e.g., "view" or "diff").</param>
        /// <param name="extension">The file extension to check (e.g., ".txt" or ".png").</param>
        /// <returns>An enumerable of supported ToolConfiguration objects.</returns>
        public IEnumerable<ToolOptions> GetSupportedTools(ToolOperationTypes operation, string extension)
        {
            return _configuration.GetSection("Tools").Get<Dictionary<string, ToolOptions>>()?.Values
                .Where(tool => tool.Enabled &&
                              tool.SupportsOperation(operation) &&
                              tool.SupportsExtension(extension)) ?? Enumerable.Empty<ToolOptions>();
        }

        /// <summary>
        /// Gets the file type mapping for the given extension.
        /// </summary>
        /// <param name="extension">The file extension to check (e.g., ".txt" or ".png").</param>
        /// <returns>The FileTypeMappingConfiguration for the extension, or null if not found.</returns>
        public FileTypeMappingOptions? GetFileTypeMapping(string extension)
        {
            return _configuration.GetSection("FileTypeMapping").Get<Dictionary<string, FileTypeMappingOptions>>()?.Values
                .FirstOrDefault(mapping => mapping.Extensions.Contains(extension, StringComparer.OrdinalIgnoreCase));
        }

        /// <summary>
        /// Gets the default tool for the given operation and extension.
        /// </summary>
        /// <param name="operation">The operation to check (e.g., "view" or "diff").</param>
        /// <param name="extension">The file extension to check (e.g., ".txt" or ".png").</param>
        /// <returns>The default ToolConfiguration, or null if not found.</returns>
        public ToolOptions? GetDefaultTool(ToolOperationTypes operation, string extension)
        {
            var fileMapping = GetFileTypeMapping(extension);
            if (fileMapping == null) return null;

            var toolName = operation switch
            {
                ToolOperationTypes.Diff => fileMapping.DefaultDiffTool,
                ToolOperationTypes.View => fileMapping.DefaultViewTool,
                _ => null
            };

            var tools = _configuration.GetSection("Tools").Get<Dictionary<string, ToolOptions>>();
            return toolName != null && tools != null && tools.TryGetValue(toolName, out var tool) ? tool : null;
        }

        /// <summary>
        /// Gets preferred tools for the given operation and extension (in priority order).
        /// </summary>
        /// <param name="operation">The operation to check (e.g., "view" or "diff").</param>
        /// <param name="extension">The file extension to check (e.g., ".txt" or ".png").</param>
        /// <returns>An enumerable of preferred ToolConfiguration objects in priority order.</returns>
        public IEnumerable<ToolOptions> GetPreferredTools(ToolOperationTypes operation, string extension)
        {
            var fileMapping = GetFileTypeMapping(extension);
            if (fileMapping == null) yield break;

            List<string> preferredToolNames;
            if (operation == ToolOperationTypes.Diff)
            {
                preferredToolNames = fileMapping.PreferredTools.Diff;
            }
            else if (operation == ToolOperationTypes.View)
            {
                preferredToolNames = fileMapping.PreferredTools.View;
            }
            else
            {
                preferredToolNames = Array.Empty<string>().ToList();
            }

            var tools = _configuration.GetSection("Tools").Get<Dictionary<string, ToolOptions>>();
            if (tools == null) yield break;

            foreach (var toolName in preferredToolNames)
            {
                if (tools.TryGetValue(toolName, out var tool) &&
                    tool.Enabled &&
                    tool.SupportsOperation(operation) &&
                    tool.SupportsExtension(extension))
                {
                    yield return tool;
                }
            }
        }
        public IEnumerable<ToolOptions> GetAllToolsForOperation(ToolOperationTypes operation)
        {
            var tools = _configuration.GetSection("Tools").Get<Dictionary<string, ToolOptions>>();
            return tools?.Values
                .Where(tool => tool.Enabled && tool.SupportsOperation(operation))
                ?? Enumerable.Empty<ToolOptions>();
        }
        public IEnumerable<string> GetSupportedExtensions(string? toolName = null, ToolOperationTypes? operation = null)
        {
            var tools = _configuration.GetSection("Tools").Get<Dictionary<string, ToolOptions>>();
            if (tools == null) yield break;

            foreach (var tool in tools.Values)
            {
                if (toolName != null && tool.Name != toolName) continue;
                if (operation != null && !tool.SupportsOperation((ToolOperationTypes)operation)) continue;
                foreach (var ext in tool.SupportedExtensions)
                {
                    yield return ext;
                }
            }
        }

        public IConfiguration GetConfiguration()
        {
            return _configuration;
        }
    }
}