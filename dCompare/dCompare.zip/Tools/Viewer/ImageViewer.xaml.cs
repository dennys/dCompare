using System.Windows.Controls;
using System.Windows.Input;

namespace dCompare.Tools.Viewer
{
    public partial class ImageViewer : UserControl, ITool
    {
        public ImageViewer(string filePath)
        {
            InitializeComponent();
            var viewModel = new ImageViewerViewModel();
            DataContext = viewModel;
            viewModel.LoadFile(filePath);

            PreviewMouseWheel += OnPreviewMouseWheel;
        }

        private void OnPreviewMouseWheel(object sender, MouseWheelEventArgs e)
        {
            if (Keyboard.Modifiers == ModifierKeys.Control)
            {
                if (DataContext is not ImageViewerViewModel viewModel) return;

                if (e.Delta > 0)
                {
                    viewModel.ZoomIn();
                }
                else
                {
                    viewModel.ZoomOut();
                }
                e.Handled = true;
            }
        }

        public void LoadFile(string filePath)
        {
            (DataContext as ImageViewerViewModel)?.LoadFile(filePath);
        }

        public UserControl GetControl()
        {
            return this;
        }
    }
}
